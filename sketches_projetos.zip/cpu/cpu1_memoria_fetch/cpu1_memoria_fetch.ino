/*
  CPU DIDATICA - FASE 1: memoria, contador de programa (PC) e busca (fetch)

  Vamos construir um processador minusculo, no estilo SAP-1:
    - memoria unica de 16 bytes (programa E dados juntos: arquitetura Von Neumann)
    - PC (Program Counter): endereco da proxima instrucao (4 bits)
    - IR (Instruction Register): instrucao que esta sendo executada (8 bits)
    - Instrucao de 8 bits = 4 bits de OPCODE + 4 bits de OPERANDO

  Nesta fase so fazemos a BUSCA (fetch):  IR <- memoria[PC] ; PC <- PC + 1
  Os 4 LEDs mostram o PC em binario.

  Comandos no Monitor Serial:  s = um passo | r = reset | m = mostrar memoria

  Ligacoes: 4 LEDs (cada um com 300 ohms) nos pinos 10, 9, 8, 7 (bit 0 ... bit 3)
*/
const uint8_t LEDS[4] = {10, 9, 8, 7};

// Programa de exemplo ("contagem regressiva"), em hexadecimal:
uint8_t memoria[16] = {
  0x15, 0x80, 0x61, 0xB1, 0xF0, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};
uint8_t PC = 0;
uint8_t IR = 0;

void imprimirBinario(uint8_t v, uint8_t bits) {
  for (int8_t i = bits - 1; i >= 0; i--) Serial.print((v >> i) & 1);
}

void mostrarPC() {
  for (uint8_t b = 0; b < 4; b++) digitalWrite(LEDS[b], (PC >> b) & 1);
}

void mostrarMemoria() {
  Serial.println(F("end | conteudo (HEX) | binario"));
  for (uint8_t i = 0; i < 16; i++) {
    Serial.print(i, HEX); Serial.print(F("   | 0x"));
    if (memoria[i] < 16) Serial.print('0');
    Serial.print(memoria[i], HEX); Serial.print(F("           | "));
    imprimirBinario(memoria[i], 8);
    if (i == PC) Serial.print(F("   <-- PC"));
    Serial.println();
  }
}

void passoBusca() {
  IR = memoria[PC];                      // T1: IR <- mem[PC]
  Serial.print(F("PC = ")); Serial.print(PC, HEX);
  Serial.print(F(" | IR = 0x")); if (IR < 16) Serial.print('0'); Serial.print(IR, HEX);
  Serial.print(F(" = ")); imprimirBinario(IR, 8);
  Serial.print(F(" | opcode = ")); imprimirBinario(IR >> 4, 4);
  Serial.print(F(" | operando = ")); imprimirBinario(IR & 0xF, 4);
  Serial.println();
  PC = (PC + 1) & 0xF;                   // T2: PC <- PC + 1 (so 4 bits: volta para 0 depois de F)
  mostrarPC();
}

void setup() {
  Serial.begin(9600);
  for (uint8_t b = 0; b < 4; b++) pinMode(LEDS[b], OUTPUT);
  mostrarPC();
  Serial.println(F("=== CPU DIDATICA - Fase 1 (busca) ==="));
  Serial.println(F("Comandos: s = passo | r = reset | m = memoria"));
  mostrarMemoria();
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 's') passoBusca();
    if (c == 'r') { PC = 0; IR = 0; mostrarPC(); Serial.println(F(">> reset")); }
    if (c == 'm') mostrarMemoria();
  }
}
