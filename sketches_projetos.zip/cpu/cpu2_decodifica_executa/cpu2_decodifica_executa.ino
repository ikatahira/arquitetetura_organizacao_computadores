/*
  CPU DIDATICA - FASE 2: decodificacao, execucao e conjunto de instrucoes

  Ciclo de instrucao (busca -> decodificacao -> execucao):
    T1: IR <- mem[PC] ; PC <- PC + 1       (busca)
    T2: a unidade de controle olha o OPCODE (decodifica)
    T3: executa e atualiza A, a flag Z e/ou a saida

  Registradores: A (acumulador, 8 bits), PC (4 bits), IR (8 bits), flag Z (zero)
  Conjunto de instrucoes (opcode em hexadecimal):
    0 NOP            1 LDI n  (A <- n)          imediato
    2 LDA m  (A <- mem[m])   direto             3 STA m  (mem[m] <- A)
    4 ADD n  (A <- A + n)    imediato           5 ADDM m (A <- A + mem[m]) direto
    6 SUB n  (A <- A - n)    imediato           7 AND n
    8 OUT    (saida <- A)                       9 JMP n  (PC <- n)
    A JZ n   (salta se Z=1)  B JNZ n (salta se Z=0)
    C XOR n                  D SUBM m (A <- A - mem[m])      F HLT (para)

  Comandos no Monitor Serial:
    s = um passo | g = executar ate HLT (maximo 60 passos) | r = reset
    m = mostrar memoria | l0, l1, l2 = carregar programa de exemplo
    w <end> <hex> = escrever na memoria. Exemplo:  w 3 2F

  Ligacoes: 4 LEDs (300 ohms) nos pinos 10, 9, 8, 7 mostram os 4 bits menos
  significativos da SAIDA.
*/
const uint8_t LEDS[4] = {10, 9, 8, 7};

uint8_t memoria[16];
uint8_t PC = 0, IR = 0, A = 0, saida = 0;
bool Z = false, parada = false;
unsigned long passos = 0;

const char* NOMES[16] = {"NOP", "LDI", "LDA", "STA", "ADD", "ADDM", "SUB", "AND",
                         "OUT", "JMP", "JZ", "JNZ", "XOR", "SUBM", "???", "HLT"};

void carregarPrograma(uint8_t n) {
  for (uint8_t i = 0; i < 16; i++) memoria[i] = 0;
  if (n == 0) {              // contagem regressiva 5,4,3,2,1
    const uint8_t p[] = {0x15, 0x80, 0x61, 0xB1, 0xF0};
    for (uint8_t i = 0; i < sizeof(p); i++) memoria[i] = p[i];
  } else if (n == 1) {       // soma de duas variaveis na memoria: 3 + 4
    const uint8_t p[] = {0x2E, 0x5F, 0x3D, 0x80, 0xF0};
    for (uint8_t i = 0; i < sizeof(p); i++) memoria[i] = p[i];
    memoria[14] = 3; memoria[15] = 4;
  } else {                   // Fibonacci (1 1 2 3 5 8 13 ...)
    const uint8_t p[] = {0x2F, 0x80, 0x5E, 0x3D, 0x2F, 0x3E, 0x2D, 0x3F, 0x90};
    for (uint8_t i = 0; i < sizeof(p); i++) memoria[i] = p[i];
    memoria[14] = 0; memoria[15] = 1;
  }
}

void resetar() { PC = 0; IR = 0; A = 0; saida = 0; Z = false; parada = false; passos = 0; }

void mostrarSaida() {
  for (uint8_t b = 0; b < 4; b++) digitalWrite(LEDS[b], (saida >> b) & 1);
}

void mostrarMemoria() {
  for (uint8_t i = 0; i < 16; i++) {
    Serial.print(i, HEX); Serial.print(F(": "));
    if (memoria[i] < 16) Serial.print('0');
    Serial.print(memoria[i], HEX);
    Serial.print(F("  "));
    Serial.print(NOMES[memoria[i] >> 4]); Serial.print(' '); Serial.print(memoria[i] & 0xF, HEX);
    if (i == PC) Serial.print(F("   <-- PC"));
    Serial.println();
  }
}

void atualizaZ() { Z = (A == 0); }

void passo() {
  if (parada) { Serial.println(F("CPU parada (HLT). Use r para reiniciar.")); return; }

  // T1: busca
  uint8_t pcAntes = PC;
  IR = memoria[PC];
  PC = (PC + 1) & 0xF;
  // T2: decodificacao
  uint8_t op = IR >> 4, n = IR & 0xF;
  // T3: execucao
  switch (op) {
    case 0x0: break;
    case 0x1: A = n; atualizaZ(); break;
    case 0x2: A = memoria[n]; atualizaZ(); break;
    case 0x3: memoria[n] = A; break;
    case 0x4: A = A + n; atualizaZ(); break;
    case 0x5: A = A + memoria[n]; atualizaZ(); break;
    case 0x6: A = A - n; atualizaZ(); break;
    case 0x7: A = A & n; atualizaZ(); break;
    case 0x8: saida = A; mostrarSaida(); break;
    case 0x9: PC = n; break;
    case 0xA: if (Z) PC = n; break;
    case 0xB: if (!Z) PC = n; break;
    case 0xC: A = A ^ n; atualizaZ(); break;
    case 0xD: A = A - memoria[n]; atualizaZ(); break;
    case 0xF: parada = true; break;
    default: break;
  }
  passos++;

  Serial.print(F("PC=")); Serial.print(pcAntes, HEX);
  Serial.print(F(" IR=0x")); if (IR < 16) Serial.print('0'); Serial.print(IR, HEX);
  Serial.print(F(" ")); Serial.print(NOMES[op]); Serial.print(' '); Serial.print(n, HEX);
  Serial.print(F(" | A=")); Serial.print(A);
  Serial.print(F(" Z=")); Serial.print(Z);
  Serial.print(F(" SAIDA=")); Serial.println(saida);
}

// Le uma linha do Serial e executa comandos de varios caracteres
void tratarLinha(String l) {
  l.trim();
  if (l.length() == 0) return;
  char c = l.charAt(0);
  if (c == 's') passo();
  else if (c == 'r') { resetar(); mostrarSaida(); Serial.println(F(">> reset")); }
  else if (c == 'm') mostrarMemoria();
  else if (c == 'g') {
    for (uint8_t i = 0; i < 60 && !parada; i++) { passo(); delay(150); }
  }
  else if (c == 'l') { carregarPrograma(l.charAt(1) - '0'); resetar(); mostrarSaida(); Serial.println(F(">> programa carregado")); mostrarMemoria(); }
  else if (c == 'w') {
    int sp = l.indexOf(' ');
    int sp2 = l.indexOf(' ', sp + 1);
    if (sp > 0 && sp2 > 0) {
      long end = strtol(l.substring(sp + 1, sp2).c_str(), NULL, 16);
      long val = strtol(l.substring(sp2 + 1).c_str(), NULL, 16);
      if (end >= 0 && end < 16) { memoria[end] = val & 0xFF; Serial.println(F(">> escrito")); }
    }
  }
}

void setup() {
  Serial.begin(9600);
  for (uint8_t b = 0; b < 4; b++) pinMode(LEDS[b], OUTPUT);
  carregarPrograma(0);
  resetar();
  mostrarSaida();
  Serial.println(F("=== CPU DIDATICA - Fase 2 ==="));
  Serial.println(F("Comandos: s passo | g executa | r reset | m memoria | l0 l1 l2 programas | w end hex"));
  mostrarMemoria();
}

void loop() {
  if (Serial.available()) {
    String l = Serial.readStringUntil('\n');
    tratarLinha(l);
  }
}
