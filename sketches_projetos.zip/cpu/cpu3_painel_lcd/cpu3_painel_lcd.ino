/*
  CPU DIDATICA - FASE 3: painel LCD, ciclos de clock e desempenho

  Igual a Fase 2, com tres novidades:
    1. Um LCD 16x2 funciona como "painel de controle" (PC, A, SAIDA, flag Z).
    2. Cada instrucao gasta CICLOS: busca = 1, execucao = 1 (2 se acessa a memoria).
       O Monitor Serial mostra o total de ciclos, o CPI (ciclos por instrucao)
       e o tempo total para um clock simulado de FREQ_HZ.
    3. Comando 'f <hz>' muda a frequencia do clock simulado (1 a 20 Hz).

  Comandos: s passo | g executa | r reset | l0 l1 l2 programas | f <hz> | m memoria

  Ligacoes do LCD 16x2 (modo 4 bits):
    LCD RS -> 12   E -> 11   D4 -> 5   D5 -> 4   D6 -> 3   D7 -> 2
    LCD VSS, RW, K(-) -> GND   VDD, A(+) -> 5V (A com resistor de 300 ohms)
    V0 (contraste) -> GND por um resistor de 1 kohm (ou potenciometro de 10 kohm)
  LEDs de saida (300 ohms) nos pinos 10, 9, 8, 7.
*/
#include <LiquidCrystal.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

const uint8_t LEDS[4] = {10, 9, 8, 7};
uint8_t memoria[16];
uint8_t PC = 0, IR = 0, A = 0, saida = 0;
bool Z = false, parada = false;
unsigned long instrucoes = 0, ciclos = 0;
uint8_t freqHz = 4;

const char* NOMES[16] = {"NOP", "LDI", "LDA", "STA", "ADD", "ADDM", "SUB", "AND",
                         "OUT", "JMP", "JZ", "JNZ", "XOR", "SUBM", "???", "HLT"};

void carregarPrograma(uint8_t n) {
  for (uint8_t i = 0; i < 16; i++) memoria[i] = 0;
  if (n == 0) {
    const uint8_t p[] = {0x15, 0x80, 0x61, 0xB1, 0xF0};
    for (uint8_t i = 0; i < sizeof(p); i++) memoria[i] = p[i];
  } else if (n == 1) {
    const uint8_t p[] = {0x2E, 0x5F, 0x3D, 0x80, 0xF0};
    for (uint8_t i = 0; i < sizeof(p); i++) memoria[i] = p[i];
    memoria[14] = 3; memoria[15] = 4;
  } else {
    const uint8_t p[] = {0x2F, 0x80, 0x5E, 0x3D, 0x2F, 0x3E, 0x2D, 0x3F, 0x90};
    for (uint8_t i = 0; i < sizeof(p); i++) memoria[i] = p[i];
    memoria[14] = 0; memoria[15] = 1;
  }
}

void resetar() { PC = 0; IR = 0; A = 0; saida = 0; Z = false; parada = false; instrucoes = 0; ciclos = 0; }

void mostrarSaida() {
  for (uint8_t b = 0; b < 4; b++) digitalWrite(LEDS[b], (saida >> b) & 1);
}

void atualizarLcd(const char* mnem, uint8_t n) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("PC:"); lcd.print(PC, HEX);
  lcd.print(' '); lcd.print(mnem); lcd.print(' '); lcd.print(n, HEX);
  lcd.setCursor(0, 1);
  lcd.print("A:"); lcd.print(A);
  lcd.print(" Z:"); lcd.print(Z ? 1 : 0);
  lcd.print(" S:"); lcd.print(saida);
}

void atualizaZ() { Z = (A == 0); }

void passo() {
  if (parada) { Serial.println(F("CPU parada (HLT). Use r para reiniciar.")); return; }
  IR = memoria[PC];
  PC = (PC + 1) & 0xF;
  uint8_t op = IR >> 4, n = IR & 0xF;
  uint8_t custo = 2;                       // 1 ciclo de busca + 1 de execucao
  switch (op) {
    case 0x0: break;
    case 0x1: A = n; atualizaZ(); break;
    case 0x2: A = memoria[n]; atualizaZ(); custo = 3; break;
    case 0x3: memoria[n] = A; custo = 3; break;
    case 0x4: A = A + n; atualizaZ(); break;
    case 0x5: A = A + memoria[n]; atualizaZ(); custo = 3; break;
    case 0x6: A = A - n; atualizaZ(); break;
    case 0x7: A = A & n; atualizaZ(); break;
    case 0x8: saida = A; mostrarSaida(); break;
    case 0x9: PC = n; break;
    case 0xA: if (Z) PC = n; break;
    case 0xB: if (!Z) PC = n; break;
    case 0xC: A = A ^ n; atualizaZ(); break;
    case 0xD: A = A - memoria[n]; atualizaZ(); custo = 3; break;
    case 0xF: parada = true; break;
    default: break;
  }
  instrucoes++;
  ciclos += custo;
  atualizarLcd(NOMES[op], n);

  Serial.print(NOMES[op]); Serial.print(' '); Serial.print(n, HEX);
  Serial.print(F(" | A=")); Serial.print(A);
  Serial.print(F(" SAIDA=")); Serial.print(saida);
  Serial.print(F(" | ciclos desta instrucao = ")); Serial.println(custo);
}

void relatorioDesempenho() {
  if (instrucoes == 0) return;
  float cpi = (float)ciclos / instrucoes;
  float tempo = (float)ciclos / freqHz;
  Serial.println(F("--- DESEMPENHO ---"));
  Serial.print(F("instrucoes = ")); Serial.println(instrucoes);
  Serial.print(F("ciclos     = ")); Serial.println(ciclos);
  Serial.print(F("CPI (ciclos por instrucao) = ")); Serial.println(cpi, 2);
  Serial.print(F("clock simulado = ")); Serial.print(freqHz); Serial.println(F(" Hz"));
  Serial.print(F("tempo = ciclos / clock = ")); Serial.print(tempo, 2); Serial.println(F(" s"));
}

void executarTudo() {
  for (uint8_t i = 0; i < 60 && !parada; i++) {
    passo();
    delay(1000UL / freqHz);                 // o "clock" da nossa CPU
  }
  relatorioDesempenho();
}

void tratarLinha(String l) {
  l.trim();
  if (l.length() == 0) return;
  char c = l.charAt(0);
  if (c == 's') passo();
  else if (c == 'g') executarTudo();
  else if (c == 'r') { resetar(); mostrarSaida(); lcd.clear(); lcd.print("CPU pronta"); Serial.println(F(">> reset")); }
  else if (c == 'l') { carregarPrograma(l.charAt(1) - '0'); resetar(); mostrarSaida(); Serial.println(F(">> programa carregado")); }
  else if (c == 'f') { int v = l.substring(1).toInt(); if (v >= 1 && v <= 20) { freqHz = v; Serial.print(F(">> clock = ")); Serial.print(freqHz); Serial.println(F(" Hz")); } }
  else if (c == 'm') {
    for (uint8_t i = 0; i < 16; i++) {
      Serial.print(i, HEX); Serial.print(F(": "));
      if (memoria[i] < 16) Serial.print('0');
      Serial.println(memoria[i], HEX);
    }
  }
}

void setup() {
  Serial.begin(9600);
  lcd.begin(16, 2);
  lcd.print("CPU Didatica");
  for (uint8_t b = 0; b < 4; b++) pinMode(LEDS[b], OUTPUT);
  carregarPrograma(0);
  resetar();
  mostrarSaida();
  Serial.println(F("=== CPU DIDATICA - Fase 3 ==="));
  Serial.println(F("Comandos: s | g | r | l0 l1 l2 | f <hz> | m"));
}

void loop() {
  if (Serial.available()) {
    String l = Serial.readStringUntil('\n');
    tratarLinha(l);
  }
}
