/*
  ESP32 PARALELO - FASE 1: dois nucleos, duas tarefas (FreeRTOS)

  O ESP32 tem DOIS nucleos (core 0 e core 1) e roda um sistema operacional de tempo
  real, o FreeRTOS. Aqui criamos duas TAREFAS e "fixamos" cada uma em um nucleo.
  Elas rodam AO MESMO TEMPO (paralelismo real, nao so alternancia como no Uno).

  Placa na IDE: "ESP32 Dev Module"  |  Velocidade do Monitor Serial: 115200
  Ligacoes: LED externo (300 ohms) no GPIO 4 -> GND (o GPIO 2 costuma ter LED na placa).
*/
const int PIN_LED_A = 2;     // LED da propria placa (na maioria dos modelos)
const int PIN_LED_B = 4;     // LED externo

void tarefaA(void *parametro) {
  pinMode(PIN_LED_A, OUTPUT);
  for (;;) {
    digitalWrite(PIN_LED_A, !digitalRead(PIN_LED_A));
    Serial.printf("[tarefa A] rodando no nucleo %d\n", xPortGetCoreID());
    vTaskDelay(500 / portTICK_PERIOD_MS);          // 500 ms
  }
}

void tarefaB(void *parametro) {
  pinMode(PIN_LED_B, OUTPUT);
  for (;;) {
    digitalWrite(PIN_LED_B, !digitalRead(PIN_LED_B));
    Serial.printf("[tarefa B] rodando no nucleo %d\n", xPortGetCoreID());
    vTaskDelay(1300 / portTICK_PERIOD_MS);         // 1300 ms
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("=== ESP32 PARALELO - Fase 1 ===");
  Serial.printf("setup() e loop() rodam no nucleo %d\n", xPortGetCoreID());
  Serial.printf("Frequencia da CPU: %d MHz\n", getCpuFrequencyMhz());

  // xTaskCreatePinnedToCore(funcao, nome, pilha em bytes, parametro, prioridade, handle, nucleo)
  xTaskCreatePinnedToCore(tarefaA, "tarefaA", 4096, NULL, 1, NULL, 0);   // nucleo 0
  xTaskCreatePinnedToCore(tarefaB, "tarefaB", 4096, NULL, 1, NULL, 1);   // nucleo 1
}

void loop() {
  vTaskDelay(1000 / portTICK_PERIOD_MS);
}
