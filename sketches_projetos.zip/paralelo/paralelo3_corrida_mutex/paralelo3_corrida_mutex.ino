/*
  ESP32 PARALELO - FASE 3: condicao de corrida, exclusao mutua (mutex) e fila

  Dois nucleos somam 1 a um CONTADOR COMPARTILHADO, 100000 vezes cada.
  O resultado correto e 200000. Testamos tres versoes:
    1) SEM protecao  -> "condicao de corrida": os dois nucleos leem, somam e gravam
                        ao mesmo tempo e PERDEM atualizacoes (resultado menor).
    2) COM MUTEX     -> so um nucleo por vez entra na SECAO CRITICA (resultado certo,
                        porem mais lento).
    3) FILA (queue)  -> um nucleo PRODUZ valores e o outro CONSOME: comunicacao entre
                        tarefas sem compartilhar variavel.

  Placa na IDE: "ESP32 Dev Module" | Monitor Serial: 115200
*/
const uint32_t VOLTAS = 100000;
volatile uint32_t contador = 0;
SemaphoreHandle_t mutex;
SemaphoreHandle_t fim[2];
QueueHandle_t fila;
bool usarMutex = false;

void tarefaSoma(void *p) {
  uint8_t id = (uint8_t)(uintptr_t)p;
  for (uint32_t i = 0; i < VOLTAS; i++) {
    if (usarMutex) xSemaphoreTake(mutex, portMAX_DELAY);
    contador = contador + 1;                  // ler -> somar -> gravar (NAO e atomico!)
    if (usarMutex) xSemaphoreGive(mutex);
  }
  xSemaphoreGive(fim[id]);
  vTaskDelete(NULL);
}

void rodarContador(bool comMutex) {
  usarMutex = comMutex;
  contador = 0;
  uint32_t t0 = micros();
  xTaskCreatePinnedToCore(tarefaSoma, "s0", 4096, (void *)0, 1, NULL, 0);
  xTaskCreatePinnedToCore(tarefaSoma, "s1", 4096, (void *)1, 1, NULL, 1);
  xSemaphoreTake(fim[0], portMAX_DELAY);
  xSemaphoreTake(fim[1], portMAX_DELAY);
  uint32_t t = micros() - t0;
  Serial.printf("%s: contador = %u (esperado %u) | perdidas = %u | tempo = %u ms\n",
                comMutex ? "COM mutex " : "SEM mutex ",
                (unsigned)contador, (unsigned)(2 * VOLTAS), (unsigned)(2 * VOLTAS - contador), (unsigned)(t / 1000));
}

// ---------- produtor/consumidor com fila ----------
void produtor(void *p) {
  for (int i = 1; i <= 5; i++) {
    xQueueSend(fila, &i, portMAX_DELAY);
    Serial.printf("[produtor, nucleo %d] enviou %d\n", xPortGetCoreID(), i);
    vTaskDelay(300 / portTICK_PERIOD_MS);
  }
  vTaskDelete(NULL);
}

void consumidor(void *p) {
  int v;
  for (int k = 0; k < 5; k++) {
    xQueueReceive(fila, &v, portMAX_DELAY);
    Serial.printf("   [consumidor, nucleo %d] recebeu %d\n", xPortGetCoreID(), v);
  }
  xSemaphoreGive(fim[0]);
  vTaskDelete(NULL);
}

void rodarFila() {
  Serial.println("--- fila: produtor (nucleo 0) -> consumidor (nucleo 1) ---");
  xTaskCreatePinnedToCore(consumidor, "cons", 4096, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(produtor, "prod", 4096, NULL, 1, NULL, 0);
  xSemaphoreTake(fim[0], portMAX_DELAY);
}

void setup() {
  Serial.begin(115200);
  delay(500);
  mutex = xSemaphoreCreateMutex();
  fim[0] = xSemaphoreCreateBinary();
  fim[1] = xSemaphoreCreateBinary();
  fila = xQueueCreate(4, sizeof(int));
  Serial.println("=== ESP32 PARALELO - Fase 3 ===");
  rodarContador(false);
  rodarContador(false);
  rodarContador(true);
  rodarFila();
  Serial.println("Fim. Rode de novo (botao EN) e compare os resultados SEM mutex.");
}

void loop() {
  delay(1000);
}
