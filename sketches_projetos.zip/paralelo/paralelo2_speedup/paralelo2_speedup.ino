/*
  ESP32 PARALELO - FASE 2: speedup, eficiencia e a Lei de Amdahl

  Problema: contar quantos numeros PRIMOS existem de 2 ate LIMITE.
  Medimos o tempo de 3 estrategias:
    1) UM nucleo faz tudo (tempo T1)
    2) DOIS nucleos, cada um com UMA METADE do intervalo (divisao em blocos)
    3) DOIS nucleos, alternando os numeros (par/impar -> divisao intercalada)

  Metricas:
    speedup = T1 / T2        eficiencia = speedup / numero de nucleos
  Os numeros maiores custam MAIS para testar: a divisao em blocos fica DESBALANCEADA
  (um nucleo termina antes e espera o outro). A divisao intercalada equilibra a carga.

  Placa na IDE: "ESP32 Dev Module" | Monitor Serial: 115200
*/
const uint32_t LIMITE = 200000;

volatile uint32_t contagem[2];
volatile uint32_t tempoNucleo[2];
SemaphoreHandle_t fimTarefa[2];

bool ehPrimo(uint32_t n) {
  if (n < 2) return false;
  if (n % 2 == 0) return n == 2;
  for (uint32_t d = 3; d * d <= n; d += 2) {
    if (n % d == 0) return false;
  }
  return true;
}

// ---------- 1 nucleo ----------
uint32_t contarSequencial() {
  uint32_t c = 0;
  for (uint32_t n = 2; n <= LIMITE; n++) if (ehPrimo(n)) c++;
  return c;
}

// ---------- 2 nucleos: o parametro diz o modo e o indice do nucleo ----------
struct Trabalho { uint8_t id; bool intercalado; };
Trabalho trabalhos[2];

void tarefaContar(void *p) {
  Trabalho *t = (Trabalho *)p;
  uint32_t ini = micros();
  uint32_t c = 0;
  if (t->intercalado) {
    for (uint32_t n = 2 + t->id; n <= LIMITE; n += 2) if (ehPrimo(n)) c++;
  } else {
    uint32_t meio = LIMITE / 2;
    uint32_t de = (t->id == 0) ? 2 : meio + 1;
    uint32_t ate = (t->id == 0) ? meio : LIMITE;
    for (uint32_t n = de; n <= ate; n++) if (ehPrimo(n)) c++;
  }
  contagem[t->id] = c;
  tempoNucleo[t->id] = micros() - ini;
  xSemaphoreGive(fimTarefa[t->id]);
  vTaskDelete(NULL);
}

uint32_t contarParalelo(bool intercalado) {
  for (uint8_t i = 0; i < 2; i++) { trabalhos[i].id = i; trabalhos[i].intercalado = intercalado; }
  xTaskCreatePinnedToCore(tarefaContar, "n0", 4096, &trabalhos[0], 1, NULL, 0);
  xTaskCreatePinnedToCore(tarefaContar, "n1", 4096, &trabalhos[1], 1, NULL, 1);
  xSemaphoreTake(fimTarefa[0], portMAX_DELAY);       // espera as duas terminarem (barreira)
  xSemaphoreTake(fimTarefa[1], portMAX_DELAY);
  return contagem[0] + contagem[1];
}

void executarTestes() {
  Serial.printf("Contando primos ate %u...\n", (unsigned)LIMITE);

  uint32_t t0 = micros();
  uint32_t r1 = contarSequencial();
  uint32_t T1 = micros() - t0;
  Serial.printf("1 nucleo           : %u primos em %u ms\n", (unsigned)r1, (unsigned)(T1 / 1000));

  t0 = micros();
  uint32_t r2 = contarParalelo(false);
  uint32_t T2 = micros() - t0;
  Serial.printf("2 nucleos (blocos) : %u primos em %u ms | nucleo0 %u ms, nucleo1 %u ms\n",
                (unsigned)r2, (unsigned)(T2 / 1000), (unsigned)(tempoNucleo[0] / 1000), (unsigned)(tempoNucleo[1] / 1000));
  Serial.printf("   speedup = %.2f | eficiencia = %.0f%%\n", (double)T1 / T2, 100.0 * T1 / T2 / 2);

  t0 = micros();
  uint32_t r3 = contarParalelo(true);
  uint32_t T3 = micros() - t0;
  Serial.printf("2 nucleos (alterna): %u primos em %u ms | nucleo0 %u ms, nucleo1 %u ms\n",
                (unsigned)r3, (unsigned)(T3 / 1000), (unsigned)(tempoNucleo[0] / 1000), (unsigned)(tempoNucleo[1] / 1000));
  Serial.printf("   speedup = %.2f | eficiencia = %.0f%%\n", (double)T1 / T3, 100.0 * T1 / T3 / 2);

  // Lei de Amdahl: S = 1 / ((1 - p) + p/N). Estimamos a fracao paralela p a partir do speedup medido (N = 2)
  double S = (double)T1 / T3;
  double p = (S > 1.0) ? (2.0 * (1.0 - 1.0 / S)) : 0.0;
  if (p > 1.0) p = 1.0;
  Serial.printf("Fracao paralelizavel estimada (Amdahl, N=2): p = %.2f\n", p);
  Serial.printf("Speedup maximo teorico com infinitos nucleos: %.1f\n", p < 1.0 ? 1.0 / (1.0 - p) : 999.0);
  Serial.println(r1 == r2 && r2 == r3 ? "Resultados iguais nas 3 estrategias." : "ATENCAO: resultados diferentes!");
}

void setup() {
  Serial.begin(115200);
  delay(500);
  fimTarefa[0] = xSemaphoreCreateBinary();
  fimTarefa[1] = xSemaphoreCreateBinary();
  Serial.println("=== ESP32 PARALELO - Fase 2 ===");
  Serial.println("Envie qualquer tecla para repetir o teste.");
  executarTestes();
}

void loop() {
  if (Serial.available()) {
    while (Serial.available()) Serial.read();
    executarTestes();
  }
  delay(50);
}
