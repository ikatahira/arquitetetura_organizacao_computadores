/*
  LABORATORIO DE PORTAS LOGICAS - FASE 3: o MEIO-SOMADOR feito de portas NAND

  Meio-somador (soma de 2 bits):   SOMA = A XOR B     VAI-UM = A AND B
  Com 4 portas NAND montamos o XOR:
      N1 = NAND(A, B)
      N2 = NAND(A, N1)
      N3 = NAND(B, N1)
      SOMA = NAND(N2, N3)         (isto e A XOR B)
  E o VAI-UM e apenas o inverso de N1:
      VAI-UM = NOT(N1)            (um inversor, a Fase 1)

  Total: 4 portas NAND + 1 inversor = 9 transistores NPN.

  Ligacoes ao Arduino:
    pino 2 -> entrada A | pino 3 -> entrada B
    saida SOMA   -> pino 4
    saida VAI-UM -> pino 5
    LEDs (300 ohms): pino 8 = A, 9 = B, 10 = SOMA, 11 = VAI-UM
*/
const uint8_t PIN_A = 2, PIN_B = 3, PIN_SOMA = 4, PIN_CARRY = 5;
const uint8_t PIN_LED_A = 8, PIN_LED_B = 9, PIN_LED_SOMA = 10, PIN_LED_CARRY = 11;

void setup() {
  Serial.begin(9600);
  pinMode(PIN_A, OUTPUT); pinMode(PIN_B, OUTPUT);
  pinMode(PIN_SOMA, INPUT); pinMode(PIN_CARRY, INPUT);
  pinMode(PIN_LED_A, OUTPUT); pinMode(PIN_LED_B, OUTPUT);
  pinMode(PIN_LED_SOMA, OUTPUT); pinMode(PIN_LED_CARRY, OUTPUT);
  Serial.println(F("=== PORTAS LOGICAS - Fase 3: meio-somador ==="));
}

void loop() {
  uint8_t acertos = 0;
  Serial.println(F("A B | SOMA VAI-UM | A+B (binario) | esperado | resultado"));
  for (uint8_t a = 0; a <= 1; a++) {
    for (uint8_t b = 0; b <= 1; b++) {
      digitalWrite(PIN_A, a); digitalWrite(PIN_B, b);
      digitalWrite(PIN_LED_A, a); digitalWrite(PIN_LED_B, b);
      delay(60);
      bool soma = digitalRead(PIN_SOMA);
      bool carry = digitalRead(PIN_CARRY);
      digitalWrite(PIN_LED_SOMA, soma);
      digitalWrite(PIN_LED_CARRY, carry);

      uint8_t esperadoSoma = a ^ b;
      uint8_t esperadoCarry = a & b;
      bool ok = (soma == esperadoSoma) && (carry == esperadoCarry);
      if (ok) acertos++;

      Serial.print(a); Serial.print(' '); Serial.print(b); Serial.print(F(" |  "));
      Serial.print(soma); Serial.print(F("      ")); Serial.print(carry);
      Serial.print(F("    |      ")); Serial.print(carry); Serial.print(soma);
      Serial.print(F("        |   ")); Serial.print(esperadoCarry); Serial.print(esperadoSoma);
      Serial.print(F("     | ")); Serial.println(ok ? F("OK") : F("ERRO"));
      delay(900);
    }
  }
  Serial.print(F("Linhas corretas: ")); Serial.print(acertos); Serial.println(F("/4"));
  Serial.println(F("-----"));
  delay(1500);
}
