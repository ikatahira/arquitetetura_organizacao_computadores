/*
  LABORATORIO DE PORTAS LOGICAS - FASE 2: NOR e NAND + tempo de propagacao

  NOR (2 transistores em PARALELO)  : Y = NOT (A OR B)
     cada entrada -> 10 kohms -> base de um transistor; os dois emissores no GND;
     os dois coletores juntos formam Y; Y ---[ 1 kohm ]--- 5V.
  NAND (2 transistores em SERIE)     : Y = NOT (A AND B)
     entrada A -> 10 kohms -> base do T1;  entrada B -> 10 kohms -> base do T2;
     coletor do T1 = Y;  emissor do T1 -> coletor do T2;  emissor do T2 -> GND;
     Y ---[ 1 kohm ]--- 5V.
  NOR e NAND sao portas UNIVERSAIS: qualquer circuito digital pode ser feito so com elas.

  Comandos no Monitor Serial:  o = testar NOR | a = testar NAND | i = testar NOT (so A)
  O programa confere a tabela-verdade e mede o TEMPO DE PROPAGACAO com o Timer1
  (cada tick do contador vale 62,5 ns a 16 MHz).

  Ligacoes ao Arduino:
    pino 2 -> entrada A | pino 3 -> entrada B
    saida Y -> pino 4 (leitura digital) E pino A0 (leitura analogica) ao mesmo tempo
    LEDs (300 ohms): pino 8 = A, 9 = B, 10 = Y lido
*/
const uint8_t PIN_A = 2, PIN_B = 3, PIN_Y = 4;
const uint8_t PIN_LED_A = 8, PIN_LED_B = 9, PIN_LED_Y = 10;
char porta = 'o';

bool esperado(char tipo, bool a, bool b) {
  if (tipo == 'o') return !(a || b);
  if (tipo == 'a') return !(a && b);
  return !a;
}

const __FlashStringHelper* nomePorta(char tipo) {
  if (tipo == 'o') return F("NOR");
  if (tipo == 'a') return F("NAND");
  return F("NOT");
}

void aplicar(bool a, bool b) {
  digitalWrite(PIN_A, a); digitalWrite(PIN_B, b);
  digitalWrite(PIN_LED_A, a); digitalWrite(PIN_LED_B, b);
}

// Mede quanto tempo (em ns) a saida demora para chegar ao valor esperado
// depois que as entradas mudam. Usa o Timer1 e leitura direta da porta D.
long medirAtrasoNs(bool aIni, bool bIni, bool aFim, bool bFim, bool yFinal) {
  aplicar(aIni, bIni);
  delay(5);
  noInterrupts();
  TCCR1A = 0; TCCR1B = 0; TCNT1 = 0;
  TCCR1B = (1 << CS10);                         // contador a 16 MHz, sem prescaler
  if (aFim) PORTD |= (1 << PD2); else PORTD &= ~(1 << PD2);
  if (bFim) PORTD |= (1 << PD3); else PORTD &= ~(1 << PD3);
  uint16_t t0 = TCNT1;
  uint16_t t1 = t0;
  uint8_t alvo = yFinal ? (1 << PD4) : 0;
  while ((PIND & (1 << PD4)) != alvo) {
    t1 = TCNT1;
    if ((uint16_t)(t1 - t0) > 60000) break;     // desiste (timeout ~3,7 ms)
  }
  t1 = TCNT1;
  interrupts();
  TCCR1B = 0;
  uint16_t ticks = t1 - t0;
  return (long)ticks * 625L / 10L;              // ticks * 62,5 ns
}

void testar() {
  Serial.print(F("--- Porta: ")); Serial.print(nomePorta(porta)); Serial.println(F(" ---"));
  Serial.println(F("A B | Y (mV) | Y lido | esperado | resultado"));
  uint8_t acertos = 0, total = 0;
  for (uint8_t a = 0; a <= 1; a++) {
    for (uint8_t b = 0; b <= 1; b++) {
      if (porta == 'i' && b == 1) continue;     // NOT so usa A
      aplicar(a, b);
      delay(40);
      int mv = (int)((long)analogRead(A0) * 5000L / 1023L);
      bool y = digitalRead(PIN_Y);
      digitalWrite(PIN_LED_Y, y);
      bool e = esperado(porta, a, b);
      bool ok = (y == e);
      total++; if (ok) acertos++;
      Serial.print(a); Serial.print(' '); Serial.print(b); Serial.print(F(" | "));
      Serial.print(mv); Serial.print(F("    | ")); Serial.print(y);
      Serial.print(F("      | ")); Serial.print(e);
      Serial.print(F("        | ")); Serial.println(ok ? F("OK") : F("ERRO"));
      delay(300);
    }
  }
  Serial.print(F("Linhas corretas: ")); Serial.print(acertos); Serial.print('/'); Serial.println(total);

  // Atraso de propagacao: de (0,0) para (1,1) a saida deve cair (NOR/NAND/NOT) ...
  long descida = medirAtrasoNs(0, 0, 1, 1, esperado(porta, 1, 1));
  // ... e de (1,1) para (0,0) a saida deve subir.
  long subida = medirAtrasoNs(1, 1, 0, 0, esperado(porta, 0, 0));
  Serial.print(F("atraso (0,0)->(1,1): ")); Serial.print(descida); Serial.println(F(" ns"));
  Serial.print(F("atraso (1,1)->(0,0): ")); Serial.print(subida); Serial.println(F(" ns"));
  Serial.println(F("(a subida costuma ser mais lenta: o resistor de 1 kohm carrega a capacitancia da saida)"));
  aplicar(0, 0);
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_A, OUTPUT); pinMode(PIN_B, OUTPUT); pinMode(PIN_Y, INPUT);
  pinMode(PIN_LED_A, OUTPUT); pinMode(PIN_LED_B, OUTPUT); pinMode(PIN_LED_Y, OUTPUT);
  Serial.println(F("=== PORTAS LOGICAS - Fase 2 ==="));
  Serial.println(F("Comandos: o = NOR | a = NAND | i = NOT"));
  testar();
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'o' || c == 'a' || c == 'i') { porta = c; testar(); }
  }
}
