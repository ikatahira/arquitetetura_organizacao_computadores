/*
  LABORATORIO DE PORTAS LOGICAS - FASE 1: o inversor (NOT) feito com transistor

  Um transistor NPN (BC337 ou PN2222A) funciona como uma CHAVE comandada por tensao.
  Montagem do inversor (RTL):
      entrada A ---[ 10 kohms ]--- base do transistor
      emissor do transistor ------ GND
      coletor do transistor ------ saida Y   e   Y ---[ 1 kohm ]--- 5V
  Entrada ALTA  -> transistor liga  -> Y ~ 0 V (BAIXO)
  Entrada BAIXA -> transistor desliga -> Y = 5 V (ALTO)   =>  Y = NOT A

  O Arduino faz de "gerador de sinais" (aplica A) e de "analisador logico" (le Y).

  Ligacoes ao Arduino:
    pino 2  -> entrada A do inversor (pelo resistor de 10 kohms)
    A0      -> saida Y do inversor      (le a tensao em mV)
    GND do Arduino ligado ao GND da placa de ensaio
    LEDs de monitoramento (300 ohms): pino 8 = A, pino 10 = Y lido pelo Arduino
*/
const uint8_t PIN_A = 2;
const uint8_t PIN_LED_A = 8;
const uint8_t PIN_LED_Y = 10;
const uint8_t PIN_Y = A0;

// Faixas de tensao tipicas de uma entrada TTL/CMOS de 5 V
const int VIL_MV = 1500;    // abaixo disso e BAIXO
const int VIH_MV = 3000;    // acima disso e ALTO

int lerMilivolts(uint8_t pino) {
  long soma = 0;
  for (uint8_t i = 0; i < 8; i++) soma += analogRead(pino);
  return (int)(soma / 8 * 5000L / 1023L);
}

const __FlashStringHelper* classificar(int mv) {
  if (mv < VIL_MV) return F("BAIXO (0)");
  if (mv > VIH_MV) return F("ALTO (1)");
  return F("INDEFINIDO");
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_A, OUTPUT);
  pinMode(PIN_LED_A, OUTPUT);
  pinMode(PIN_LED_Y, OUTPUT);
  Serial.println(F("=== PORTAS LOGICAS - Fase 1: inversor (NOT) ==="));
  Serial.println(F("A | Y medido (mV) | nivel logico   | esperado | resultado"));
}

void loop() {
  uint8_t acertos = 0;
  for (uint8_t a = 0; a <= 1; a++) {
    digitalWrite(PIN_A, a);
    digitalWrite(PIN_LED_A, a);
    delay(50);
    int mv = lerMilivolts(PIN_Y);
    bool y = mv > 2500;
    digitalWrite(PIN_LED_Y, y);

    bool esperado = !a;
    bool ok = (y == esperado);
    if (ok) acertos++;

    Serial.print(a); Serial.print(F(" | ")); Serial.print(mv); Serial.print(F(" mV        | "));
    Serial.print(classificar(mv)); Serial.print(F(" | ")); Serial.print(esperado);
    Serial.print(F("        | ")); Serial.println(ok ? F("OK") : F("ERRO"));
    delay(800);
  }
  Serial.print(F("Linhas corretas: ")); Serial.print(acertos); Serial.println(F("/2"));
  Serial.println(F("-----"));
  delay(1500);
}
