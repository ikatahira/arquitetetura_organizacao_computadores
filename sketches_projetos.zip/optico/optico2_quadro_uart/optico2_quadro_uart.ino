/*
  TELEGRAFO OPTICO - FASE 2: um quadro (frame) estilo UART

  Digite UM caractere no Monitor Serial. O Arduino o transmite pela luz do LED
  e o recebe pelo sensor (teste "loopback"). O QUADRO tem 11 bits:

      1 bit START (0)  +  8 bits de DADOS (LSB primeiro)  +  1 bit de PARIDADE PAR  +  1 bit STOP (1)

  A luz e a "linha": LED ACESO = 1 (estado de repouso) e LED APAGADO = 0.
  A velocidade e o TEMPO DE BIT (TBIT_MS). O receptor le o sensor no MEIO de cada bit.

  Ligacoes: as mesmas da Fase 1.
*/
const uint8_t PIN_LED = 8;
const uint8_t PIN_SENSOR = A0;
const uint8_t PIN_OK = 10;      // LED verde (opcional): quadro valido
const uint8_t PIN_ERRO = 11;    // LED vermelho (opcional): erro
unsigned int TBIT_MS = 200;     // 200 ms por bit = 5 bits por segundo (LDR e lento!)

int limiar = 512;
bool luzAumenta = true;

int lerMedia(uint8_t n) {
  long soma = 0;
  for (uint8_t i = 0; i < n; i++) { soma += analogRead(PIN_SENSOR); delay(3); }
  return soma / n;
}

void calibrar() {
  digitalWrite(PIN_LED, LOW);  delay(400); int apagado = lerMedia(20);
  digitalWrite(PIN_LED, HIGH); delay(400); int aceso = lerMedia(20);
  luzAumenta = aceso > apagado;
  limiar = (aceso + apagado) / 2;
  Serial.print(F("calibrado: apagado=")); Serial.print(apagado);
  Serial.print(F(" aceso=")); Serial.print(aceso);
  Serial.print(F(" limiar=")); Serial.println(limiar);
}

bool lerBitDoSensor() {
  int v = analogRead(PIN_SENSOR);
  return luzAumenta ? (v > limiar) : (v < limiar);
}

uint8_t paridadePar(uint8_t v) {
  uint8_t p = 0;
  while (v) { p ^= (v & 1); v >>= 1; }
  return p;
}

// Transmite e, no mesmo instante, "recebe" cada bit lendo o sensor no meio do bit
void enviarEReceber(uint8_t byteEnviado, uint16_t &quadroRecebido) {
  uint16_t quadro = 0;
  quadro |= 0;                                        // bit 0: START = 0
  quadro |= (uint16_t)byteEnviado << 1;               // bits 1 a 8: dados (LSB primeiro)
  quadro |= (uint16_t)paridadePar(byteEnviado) << 9;  // bit 9: paridade par
  quadro |= (uint16_t)1 << 10;                        // bit 10: STOP = 1

  quadroRecebido = 0;
  for (uint8_t i = 0; i < 11; i++) {
    digitalWrite(PIN_LED, (quadro >> i) & 1);
    delay(TBIT_MS / 2);
    if (lerBitDoSensor()) quadroRecebido |= (uint16_t)1 << i;   // amostra no MEIO do bit
    delay(TBIT_MS - TBIT_MS / 2);
  }
  digitalWrite(PIN_LED, HIGH);                        // linha volta ao repouso (1)
}

void imprimirQuadro(uint16_t q) {
  Serial.print(F("START="));  Serial.print(q & 1);
  Serial.print(F(" DADOS=")); for (int8_t i = 8; i >= 1; i--) Serial.print((q >> i) & 1);
  Serial.print(F(" PAR="));   Serial.print((q >> 9) & 1);
  Serial.print(F(" STOP="));  Serial.print((q >> 10) & 1);
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_LED, OUTPUT); pinMode(PIN_OK, OUTPUT); pinMode(PIN_ERRO, OUTPUT);
  Serial.println(F("=== TELEGRAFO OPTICO - Fase 2 ==="));
  calibrar();
  Serial.print(F("Tempo de bit = ")); Serial.print(TBIT_MS); Serial.print(F(" ms -> ")); Serial.print(1000.0 / TBIT_MS, 1); Serial.println(F(" bits/s"));
  Serial.println(F("Digite um caractere e envie."));
}

void loop() {
  if (!Serial.available()) return;
  char c = Serial.read();
  if (c == '\n' || c == '\r') return;

  uint16_t rx;
  enviarEReceber((uint8_t)c, rx);

  uint8_t dados = (rx >> 1) & 0xFF;
  bool startOk = (rx & 1) == 0;
  bool stopOk  = ((rx >> 10) & 1) == 1;
  bool parOk   = ((rx >> 9) & 1) == paridadePar(dados);

  Serial.print(F("enviado '")); Serial.print(c); Serial.print(F("' = 0x")); Serial.print((uint8_t)c, HEX);
  Serial.print(F(" | quadro RX: ")); imprimirQuadro(rx); Serial.println();
  Serial.print(F("recebido '")); Serial.print((char)dados); Serial.print(F("' = 0x")); Serial.print(dados, HEX);
  Serial.print(F(" | start ")); Serial.print(startOk ? F("ok") : F("ERRO"));
  Serial.print(F(" | paridade ")); Serial.print(parOk ? F("ok") : F("ERRO"));
  Serial.print(F(" | stop ")); Serial.println(stopOk ? F("ok") : F("ERRO"));

  bool tudoOk = startOk && stopOk && parOk && (dados == (uint8_t)c);
  digitalWrite(PIN_OK, tudoOk);
  digitalWrite(PIN_ERRO, !tudoOk);
}
