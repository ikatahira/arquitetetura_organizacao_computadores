/*
  TELEGRAFO OPTICO - FASE 1: o canal de luz e o conversor analogico-digital (ADC)

  Um LED vai transmitir e um sensor de luz vai receber, como numa fibra optica.
  Sensor: LDR (resistor que depende da luz) OU fototransistor do kit IR.
  O Arduino le o sensor com o ADC de 10 bits: valores de 0 a 1023 (0 V a 5 V).

  Nesta fase voce:
    - mede o nivel com o LED APAGADO e com o LED ACESO,
    - descobre a POLARIDADE do sensor (a luz aumenta ou diminui a leitura?),
    - calcula o LIMIAR (meio do caminho) que separa o bit 0 do bit 1.

  Ligacoes:
    LED (qualquer cor) -> pino 8, com resistor de 300 ohms para o GND
    Sensor LDR: um terminal no 5V; o outro no pino A0 E num resistor de 10 kohms ao GND
    (fototransistor IR: coletor no 5V por um resistor de 10 kohms e no pino A0;
     emissor no GND. A polaridade e detectada sozinha.)
    Aponte o LED para o sensor (um tubinho de papel preto ajuda a bloquear a luz do ambiente).
*/
const uint8_t PIN_LED = 8;
const uint8_t PIN_SENSOR = A0;

int lerMedia(uint8_t n) {
  long soma = 0;
  for (uint8_t i = 0; i < n; i++) { soma += analogRead(PIN_SENSOR); delay(5); }
  return soma / n;
}

void imprimirBinario(uint16_t v, uint8_t bits) {
  for (int8_t i = bits - 1; i >= 0; i--) Serial.print((v >> i) & 1);
}

void imprimirLeitura(const __FlashStringHelper* nome, int v) {
  Serial.print(nome);
  Serial.print(F(": ADC = ")); Serial.print(v);
  Serial.print(F(" | BIN10 = ")); imprimirBinario(v, 10);
  Serial.print(F(" | HEX = 0x")); Serial.print(v, HEX);
  Serial.print(F(" | tensao = ")); Serial.print(v * 5.0 / 1023.0, 2); Serial.println(F(" V"));
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_LED, OUTPUT);
  Serial.println(F("=== TELEGRAFO OPTICO - Fase 1: calibracao ==="));
  Serial.print(F("Resolucao do ADC: 5 V / 1023 = ")); Serial.print(5000.0 / 1023.0, 2); Serial.println(F(" mV por degrau"));
}

void loop() {
  digitalWrite(PIN_LED, LOW);  delay(400);
  int apagado = lerMedia(20);
  digitalWrite(PIN_LED, HIGH); delay(400);
  int aceso = lerMedia(20);

  imprimirLeitura(F("LED apagado"), apagado);
  imprimirLeitura(F("LED aceso   "), aceso);

  bool luzAumenta = aceso > apagado;
  int limiar = (aceso + apagado) / 2;
  int contraste = abs(aceso - apagado);

  Serial.print(F("Polaridade: ")); Serial.println(luzAumenta ? F("luz AUMENTA a leitura") : F("luz DIMINUI a leitura (invertido)"));
  Serial.print(F("Limiar = ")); Serial.print(limiar); Serial.print(F(" | contraste = ")); Serial.println(contraste);
  if (contraste < 100) Serial.println(F("ATENCAO: contraste baixo. Aproxime o LED do sensor ou reduza a luz do ambiente."));
  else Serial.println(F("Canal OK para a Fase 2."));
  Serial.println(F("-----"));
  delay(1500);
}
