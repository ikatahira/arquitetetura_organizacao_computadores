/*
  TELEGRAFO OPTICO - FASE 3: textos, taxa de erro (BER) e largura de banda

  Digite uma frase no Monitor Serial: cada caractere vira um quadro de 11 bits.
  No fim o programa mostra:
    - quantos caracteres chegaram certos e quantos tiveram erro de paridade/dados
    - a TAXA DE ERRO DE BITS (BER) = bits errados / bits enviados
    - a taxa BRUTA (bits/s no canal) e a taxa UTIL (bits de dados por segundo)

  Para mudar a velocidade, envie uma linha que comeca com # e o tempo de bit em ms:
      #100   (100 ms por bit)     #20   (20 ms por bit)
  Descubra a velocidade em que o seu sensor comeca a errar!

  Ligacoes: as mesmas da Fase 1.
*/
const uint8_t PIN_LED = 8;
const uint8_t PIN_SENSOR = A0;
const uint8_t PIN_OK = 10;
const uint8_t PIN_ERRO = 11;
unsigned int TBIT_MS = 200;

int limiar = 512;
bool luzAumenta = true;

int lerMedia(uint8_t n) {
  long soma = 0;
  for (uint8_t i = 0; i < n; i++) { soma += analogRead(PIN_SENSOR); delay(3); }
  return soma / n;
}

void calibrar() {
  digitalWrite(PIN_LED, LOW);  delay(400); int apagado = lerMedia(20);
  digitalWrite(PIN_LED, HIGH); delay(400); int aceso = lerMedia(20);
  luzAumenta = aceso > apagado;
  limiar = (aceso + apagado) / 2;
  Serial.print(F("calibrado: limiar=")); Serial.print(limiar);
  Serial.print(F(" polaridade=")); Serial.println(luzAumenta ? F("normal") : F("invertida"));
}

bool lerBitDoSensor() {
  int v = analogRead(PIN_SENSOR);
  return luzAumenta ? (v > limiar) : (v < limiar);
}

uint8_t paridadePar(uint8_t v) {
  uint8_t p = 0;
  while (v) { p ^= (v & 1); v >>= 1; }
  return p;
}

uint8_t contarBits(uint16_t v) {
  uint8_t n = 0;
  while (v) { n += v & 1; v >>= 1; }
  return n;
}

uint16_t montarQuadro(uint8_t b) {
  return ((uint16_t)1 << 10) | ((uint16_t)paridadePar(b) << 9) | ((uint16_t)b << 1);
}

uint16_t enviarEReceber(uint16_t quadro) {
  uint16_t rx = 0;
  for (uint8_t i = 0; i < 11; i++) {
    digitalWrite(PIN_LED, (quadro >> i) & 1);
    delay(TBIT_MS / 2);
    if (lerBitDoSensor()) rx |= (uint16_t)1 << i;
    delay(TBIT_MS - TBIT_MS / 2);
  }
  digitalWrite(PIN_LED, HIGH);
  return rx;
}

void transmitirTexto(String s) {
  unsigned int n = s.length();
  unsigned int certos = 0, errosParidade = 0, errosDados = 0, bitsErrados = 0;
  String recebido = "";
  unsigned long t0 = millis();

  for (unsigned int k = 0; k < n; k++) {
    uint8_t c = s.charAt(k);
    uint16_t tx = montarQuadro(c);
    uint16_t rx = enviarEReceber(tx);
    uint8_t dados = (rx >> 1) & 0xFF;
    bool parOk = ((rx >> 9) & 1) == paridadePar(dados);
    bitsErrados += contarBits((tx ^ rx) & 0x7FF);      // XOR mostra exatamente quais bits mudaram
    if (!parOk) errosParidade++;
    if (dados != c) errosDados++;
    if (parOk && dados == c) certos++;
    recebido += (char)dados;
  }
  unsigned long ms = millis() - t0;

  Serial.print(F("Enviado : ")); Serial.println(s);
  Serial.print(F("Recebido: ")); Serial.println(recebido);
  Serial.print(F("caracteres certos = ")); Serial.print(certos); Serial.print('/'); Serial.println(n);
  Serial.print(F("erros de paridade = ")); Serial.print(errosParidade);
  Serial.print(F(" | erros de dados = ")); Serial.println(errosDados);
  float ber = (float)bitsErrados / (n * 11.0);
  Serial.print(F("BER = ")); Serial.print(bitsErrados); Serial.print(F(" bits errados de ")); Serial.print(n * 11);
  Serial.print(F(" = ")); Serial.println(ber, 4);
  Serial.print(F("taxa bruta = ")); Serial.print(1000.0 / TBIT_MS, 1); Serial.print(F(" bits/s | taxa util = "));
  Serial.print(n * 8000.0 / ms, 1); Serial.println(F(" bits de dados/s"));
  digitalWrite(PIN_OK, certos == n);
  digitalWrite(PIN_ERRO, certos != n);
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_LED, OUTPUT); pinMode(PIN_OK, OUTPUT); pinMode(PIN_ERRO, OUTPUT);
  Serial.println(F("=== TELEGRAFO OPTICO - Fase 3 ==="));
  calibrar();
  Serial.println(F("Digite uma frase. Para mudar a velocidade: #<ms por bit>"));
}

void loop() {
  if (!Serial.available()) return;
  String linha = Serial.readStringUntil('\n');
  linha.trim();
  if (linha.length() == 0) return;
  if (linha.charAt(0) == '#') {
    int v = linha.substring(1).toInt();
    if (v >= 2 && v <= 1000) { TBIT_MS = v; Serial.print(F(">> tempo de bit = ")); Serial.print(TBIT_MS); Serial.println(F(" ms")); }
    return;
  }
  if (linha.length() > 40) linha = linha.substring(0, 40);
  transmitirTexto(linha);
}
