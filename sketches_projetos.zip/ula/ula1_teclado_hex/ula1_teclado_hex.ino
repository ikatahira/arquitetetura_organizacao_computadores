/*
  MINI-ULA DE 4 BITS - FASE 1: teclado matricial e numeros hexadecimais

  Um teclado 4x4 tem 16 teclas = 16 valores = 1 digito HEXADECIMAL (4 bits).
    Teclas 0-9 -> 0 a 9 | A,B,C,D -> 10 a 13 | * -> 14 (E) | # -> 15 (F)

  Como o teclado funciona (varredura/multiplexacao):
    4 linhas (saidas) + 4 colunas (entradas com pull-up) = 8 fios para 16 teclas.
    O Arduino poe UMA linha em LOW de cada vez e olha qual coluna caiu para LOW.

  Ligacoes:
    Linhas do teclado  -> pinos 2, 3, 4, 5
    Colunas do teclado -> pinos 6, 7, 8, 9
    LEDs (cada um com resistor de 300 ohms para o GND):
      bit 0 = LED verde no pino 13   bit 1 = LED amarelo no pino 12
      bit 2 = LED vermelho no pino 11  bit 3 = LED azul no pino 10
*/
const uint8_t LINHAS[4]  = {2, 3, 4, 5};
const uint8_t COLUNAS[4] = {6, 7, 8, 9};
const uint8_t LEDS[4]    = {13, 12, 11, 10};   // bit 0 ... bit 3
const char TECLAS[4][4]  = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

void iniciarTeclado() {
  for (uint8_t r = 0; r < 4; r++) { pinMode(LINHAS[r], OUTPUT); digitalWrite(LINHAS[r], HIGH); }
  for (uint8_t c = 0; c < 4; c++) pinMode(COLUNAS[c], INPUT_PULLUP);
}

// Varredura: devolve a tecla pressionada ou 0
char lerTecla() {
  for (uint8_t r = 0; r < 4; r++) {
    digitalWrite(LINHAS[r], LOW);
    for (uint8_t c = 0; c < 4; c++) {
      if (digitalRead(COLUNAS[c]) == LOW) {
        digitalWrite(LINHAS[r], HIGH);
        return TECLAS[r][c];
      }
    }
    digitalWrite(LINHAS[r], HIGH);
  }
  return 0;
}

// Espera apertar, espera soltar (anti-repique) e devolve a tecla
char esperarTecla() {
  char t;
  while ((t = lerTecla()) == 0) { }
  delay(30);
  while (lerTecla() != 0) { }
  delay(30);
  return t;
}

int8_t valorHex(char t) {
  if (t >= '0' && t <= '9') return t - '0';
  if (t >= 'A' && t <= 'D') return 10 + (t - 'A');
  if (t == '*') return 14;
  if (t == '#') return 15;
  return -1;
}

void mostrar4bits(uint8_t v) {
  for (uint8_t b = 0; b < 4; b++) digitalWrite(LEDS[b], (v >> b) & 1);
}

void imprimirBinario(uint8_t v, uint8_t bits) {
  for (int8_t i = bits - 1; i >= 0; i--) Serial.print((v >> i) & 1);
}

void setup() {
  Serial.begin(9600);
  iniciarTeclado();
  for (uint8_t b = 0; b < 4; b++) pinMode(LEDS[b], OUTPUT);
  Serial.println(F("=== MINI-ULA - Fase 1: teclado hexadecimal ==="));
  Serial.println(F("Aperte uma tecla. * = E e # = F."));
}

void loop() {
  char tecla = esperarTecla();
  uint8_t v = valorHex(tecla);
  mostrar4bits(v);

  int8_t comSinal = (v & 0b1000) ? (int8_t)v - 16 : (int8_t)v;   // complemento de dois em 4 bits

  Serial.print(F("tecla '")); Serial.print(tecla);
  Serial.print(F("' | HEX = ")); Serial.print(v, HEX);
  Serial.print(F(" | BIN = ")); imprimirBinario(v, 4);
  Serial.print(F(" | DEC sem sinal = ")); Serial.print(v);
  Serial.print(F(" | DEC com sinal (compl. de 2) = ")); Serial.println(comSinal);
}
