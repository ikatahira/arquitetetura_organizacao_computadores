/*
  MINI-ULA DE 4 BITS - FASE 3: ULA feita so com portas logicas + acumulador

  Novidades:
    - A soma e a subtracao usam um SOMADOR/SUBTRATOR montado bit a bit com
      portas logicas (XOR, AND, OR), igual ao hardware de verdade.
      Subtracao: troca B por NOT B (XOR com 1) e entra com carry-in = 1.
    - Comando 't' no Monitor Serial: AUTOTESTE com as 256 combinacoes de A e B.
    - Comando 'a': liga/desliga o MODO ACUMULADOR. Nesse modo a ULA guarda o
      resultado no registrador ACC e a proxima instrucao usa ACC como operando A
      (so digite B e o opcode). Comando 'z': zera o ACC.

  Ligacoes: as mesmas da Fase 2.
*/
const uint8_t LINHAS[4]  = {2, 3, 4, 5};
const uint8_t COLUNAS[4] = {6, 7, 8, 9};
const uint8_t LEDS[4]    = {13, 12, 11, 10};
const uint8_t PIN_RGB[3] = {A0, A1, A2};
const bool COMUM_ANODO   = false;
const char TECLAS[4][4]  = {
  {'1', '2', '3', 'A'}, {'4', '5', '6', 'B'}, {'7', '8', '9', 'C'}, {'*', '0', '#', 'D'}
};

uint8_t resultado, flagC, flagZ, flagN, flagV;
uint8_t acc = 0;
bool modoAcumulador = false;

void iniciarTeclado() {
  for (uint8_t r = 0; r < 4; r++) { pinMode(LINHAS[r], OUTPUT); digitalWrite(LINHAS[r], HIGH); }
  for (uint8_t c = 0; c < 4; c++) pinMode(COLUNAS[c], INPUT_PULLUP);
}
char lerTecla() {
  for (uint8_t r = 0; r < 4; r++) {
    digitalWrite(LINHAS[r], LOW);
    for (uint8_t c = 0; c < 4; c++) {
      if (digitalRead(COLUNAS[c]) == LOW) { digitalWrite(LINHAS[r], HIGH); return TECLAS[r][c]; }
    }
    digitalWrite(LINHAS[r], HIGH);
  }
  return 0;
}
// Igual a Fase 2, mas tambem atende comandos do Serial enquanto espera
char esperarTecla() {
  char t;
  while ((t = lerTecla()) == 0) {
    if (Serial.available()) return 0;
  }
  delay(30);
  while (lerTecla() != 0) { }
  delay(30);
  return t;
}
uint8_t valorHex(char t) {
  if (t >= '0' && t <= '9') return t - '0';
  if (t >= 'A' && t <= 'D') return 10 + (t - 'A');
  if (t == '*') return 14;
  return 15;
}
void imprimirBinario(uint8_t v, uint8_t bits) {
  for (int8_t i = bits - 1; i >= 0; i--) Serial.print((v >> i) & 1);
}
void mostrarLeds(uint8_t v) {
  for (uint8_t b = 0; b < 4; b++) digitalWrite(LEDS[b], (v >> b) & 1);
}
void mostrarFlags() {
  uint8_t f[3] = {flagC, flagZ, flagN};
  for (uint8_t i = 0; i < 3; i++) digitalWrite(PIN_RGB[i], COMUM_ANODO ? !f[i] : f[i]);
}

// ---------- Somador completo de 1 bit ----------
void somaCompleta(uint8_t a, uint8_t b, uint8_t cin, uint8_t &s, uint8_t &cout) {
  s    = a ^ b ^ cin;
  cout = (a & b) | (cin & (a ^ b));
}

// ---------- Somador/Subtrator de 4 bits (ripple carry) ----------
// sub = 0 -> A + B      sub = 1 -> A + (B XOR 1111) + 1  = A - B
uint8_t somadorSubtrator(uint8_t a, uint8_t b, uint8_t sub, uint8_t &carryFinal, uint8_t &overflow) {
  uint8_t carry = sub, r = 0, carryAntesDoUltimo = 0;
  for (uint8_t i = 0; i < 4; i++) {
    uint8_t bi = ((b >> i) & 1) ^ sub;          // XOR com "sub" inverte B na subtracao
    uint8_t s;
    if (i == 3) carryAntesDoUltimo = carry;
    somaCompleta((a >> i) & 1, bi, carry, s, carry);
    r |= s << i;
  }
  carryFinal = carry;
  overflow = carry ^ carryAntesDoUltimo;        // overflow = carry que entra XOR carry que sai do bit de sinal
  return r;
}

void ula(uint8_t a, uint8_t b, uint8_t op) {
  uint8_t r = 0, c = 0, v = 0;
  switch (op) {
    case 0: r = somadorSubtrator(a, b, 0, c, v); break;
    case 1: r = somadorSubtrator(a, b, 1, c, v); break;
    case 2: r = a & b; break;
    case 3: r = a | b; break;
    case 4: r = a ^ b; break;
    case 5: r = (~a) & 0xF; break;
    case 6: c = (a >> 3) & 1; r = (a << 1) & 0xF; break;
    case 7: c = a & 1;        r = a >> 1;         break;
    default: r = 0; break;
  }
  resultado = r; flagC = c; flagV = v;
  flagZ = (r == 0);
  flagN = (r >> 3) & 1;
}

// Referencia "de verdade" (aritmetica do C) para conferir o hardware simulado
uint8_t referenciaSoma(uint8_t a, uint8_t b) { return (a + b) & 0xF; }
uint8_t referenciaSub(uint8_t a, uint8_t b)  { return (a - b) & 0xF; }

void autoteste() {
  uint16_t erros = 0;
  for (uint8_t a = 0; a < 16; a++) {
    for (uint8_t b = 0; b < 16; b++) {
      ula(a, b, 0); if (resultado != referenciaSoma(a, b)) erros++;
      ula(a, b, 1); if (resultado != referenciaSub(a, b))  erros++;
    }
  }
  Serial.print(F("AUTOTESTE: 512 operacoes, erros = "));
  Serial.println(erros);
  if (erros == 0) Serial.println(F("A ULA de portas logicas esta CORRETA!"));
}

void tratarComandosSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 't') autoteste();
    if (c == 'a') { modoAcumulador = !modoAcumulador; Serial.print(F(">> modo acumulador: ")); Serial.println(modoAcumulador ? F("LIGADO") : F("desligado")); }
    if (c == 'z') { acc = 0; Serial.println(F(">> ACC = 0")); }
  }
}

void setup() {
  Serial.begin(9600);
  iniciarTeclado();
  for (uint8_t b = 0; b < 4; b++) pinMode(LEDS[b], OUTPUT);
  for (uint8_t i = 0; i < 3; i++) pinMode(PIN_RGB[i], OUTPUT);
  Serial.println(F("=== MINI-ULA - Fase 3 ==="));
  Serial.println(F("Serial: t = autoteste | a = modo acumulador | z = zera ACC"));
}

void loop() {
  uint8_t a, b, op;
  char t;

  if (modoAcumulador) {
    a = acc;
    Serial.print(F("ACC = ")); Serial.println(a, HEX);
  } else {
    t = esperarTecla(); if (t == 0) { tratarComandosSerial(); return; }
    a = valorHex(t); Serial.print(F("A = ")); Serial.println(a, HEX);
  }
  t = esperarTecla(); if (t == 0) { tratarComandosSerial(); return; }
  b = valorHex(t); Serial.print(F("B = ")); Serial.println(b, HEX);
  t = esperarTecla(); if (t == 0) { tratarComandosSerial(); return; }
  op = valorHex(t); Serial.print(F("opcode = ")); Serial.println(op, HEX);

  ula(a, b, op);
  mostrarLeds(resultado);
  mostrarFlags();
  if (modoAcumulador) acc = resultado;       // o resultado volta para o registrador ACC

  imprimirBinario(a, 4); Serial.print(F(" op")); Serial.print(op, HEX); Serial.print(' ');
  imprimirBinario(b, 4); Serial.print(F(" = ")); imprimirBinario(resultado, 4);
  Serial.print(F(" | C=")); Serial.print(flagC);
  Serial.print(F(" Z="));   Serial.print(flagZ);
  Serial.print(F(" N="));   Serial.print(flagN);
  Serial.print(F(" V="));   Serial.println(flagV);
}
