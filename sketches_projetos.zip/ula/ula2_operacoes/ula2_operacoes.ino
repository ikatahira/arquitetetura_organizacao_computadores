/*
  MINI-ULA DE 4 BITS - FASE 2: a Unidade Logica e Aritmetica (ULA)

  Uma "instrucao" tem 3 teclas (como um mini codigo de maquina):
      1a tecla = operando A    2a tecla = operando B    3a tecla = OPCODE
  Opcodes (hexadecimal):
      0 = A + B    1 = A - B    2 = A AND B   3 = A OR B
      4 = A XOR B  5 = NOT A    6 = A << 1    7 = A >> 1
  O resultado aparece nos 4 LEDs. O LED RGB mostra os SINAIS (flags):
      VERMELHO = C (vai-um / carry)   VERDE = Z (resultado zero)   AZUL = N (negativo)
  A flag V (overflow, estouro com sinal) aparece no Monitor Serial.

  Ligacoes: as mesmas da Fase 1, mais o LED RGB (cada cor com 300 ohms):
      cor vermelha -> A0   cor verde -> A1   cor azul -> A2
      (catodo comum: pino longo no GND. Se o seu for anodo comum, mude COMUM_ANODO)
*/
const uint8_t LINHAS[4]  = {2, 3, 4, 5};
const uint8_t COLUNAS[4] = {6, 7, 8, 9};
const uint8_t LEDS[4]    = {13, 12, 11, 10};
const uint8_t PIN_RGB[3] = {A0, A1, A2};
const bool COMUM_ANODO   = false;
const char TECLAS[4][4]  = {
  {'1', '2', '3', 'A'}, {'4', '5', '6', 'B'}, {'7', '8', '9', 'C'}, {'*', '0', '#', 'D'}
};

uint8_t resultado, flagC, flagZ, flagN, flagV;

void iniciarTeclado() {
  for (uint8_t r = 0; r < 4; r++) { pinMode(LINHAS[r], OUTPUT); digitalWrite(LINHAS[r], HIGH); }
  for (uint8_t c = 0; c < 4; c++) pinMode(COLUNAS[c], INPUT_PULLUP);
}
char lerTecla() {
  for (uint8_t r = 0; r < 4; r++) {
    digitalWrite(LINHAS[r], LOW);
    for (uint8_t c = 0; c < 4; c++) {
      if (digitalRead(COLUNAS[c]) == LOW) { digitalWrite(LINHAS[r], HIGH); return TECLAS[r][c]; }
    }
    digitalWrite(LINHAS[r], HIGH);
  }
  return 0;
}
char esperarTecla() {
  char t;
  while ((t = lerTecla()) == 0) { }
  delay(30);
  while (lerTecla() != 0) { }
  delay(30);
  return t;
}
uint8_t valorHex(char t) {
  if (t >= '0' && t <= '9') return t - '0';
  if (t >= 'A' && t <= 'D') return 10 + (t - 'A');
  if (t == '*') return 14;
  return 15;
}
void imprimirBinario(uint8_t v, uint8_t bits) {
  for (int8_t i = bits - 1; i >= 0; i--) Serial.print((v >> i) & 1);
}
void mostrarLeds(uint8_t v) {
  for (uint8_t b = 0; b < 4; b++) digitalWrite(LEDS[b], (v >> b) & 1);
}
void mostrarFlags() {
  uint8_t f[3] = {flagC, flagZ, flagN};
  for (uint8_t i = 0; i < 3; i++) digitalWrite(PIN_RGB[i], COMUM_ANODO ? !f[i] : f[i]);
}

// ---------- A ULA ----------
void ula(uint8_t a, uint8_t b, uint8_t op) {
  uint8_t r = 0, c = 0, v = 0;
  switch (op) {
    case 0: {                                   // soma
      uint8_t s = a + b;
      r = s & 0xF; c = s >> 4;
      v = (((a ^ r) & (b ^ r)) & 0b1000) ? 1 : 0;
    } break;
    case 1: {                                   // subtracao = A + (NOT B) + 1  (complemento de dois)
      uint8_t s = a + ((~b) & 0xF) + 1;
      r = s & 0xF; c = s >> 4;
      v = (((a ^ b) & (a ^ r)) & 0b1000) ? 1 : 0;
    } break;
    case 2: r = a & b; break;
    case 3: r = a | b; break;
    case 4: r = a ^ b; break;
    case 5: r = (~a) & 0xF; break;
    case 6: c = (a >> 3) & 1; r = (a << 1) & 0xF; break;
    case 7: c = a & 1;        r = a >> 1;         break;
    default: r = 0; break;
  }
  resultado = r; flagC = c; flagV = v;
  flagZ = (r == 0);
  flagN = (r >> 3) & 1;
}

const char* nomeOp(uint8_t op) {
  const char* nomes[8] = {"ADD", "SUB", "AND", "OR", "XOR", "NOT A", "SHL A", "SHR A"};
  return op < 8 ? nomes[op] : "???";
}

void setup() {
  Serial.begin(9600);
  iniciarTeclado();
  for (uint8_t b = 0; b < 4; b++) pinMode(LEDS[b], OUTPUT);
  for (uint8_t i = 0; i < 3; i++) pinMode(PIN_RGB[i], OUTPUT);
  Serial.println(F("=== MINI-ULA - Fase 2 ==="));
  Serial.println(F("Digite: A, B, opcode (0 ADD 1 SUB 2 AND 3 OR 4 XOR 5 NOT 6 SHL 7 SHR)"));
}

void loop() {
  Serial.println(F("--- nova instrucao ---"));
  uint8_t a = valorHex(esperarTecla());  Serial.print(F("A = "));  Serial.println(a, HEX);
  uint8_t b = valorHex(esperarTecla());  Serial.print(F("B = "));  Serial.println(b, HEX);
  uint8_t op = valorHex(esperarTecla()); Serial.print(F("opcode = ")); Serial.println(op, HEX);

  ula(a, b, op);
  mostrarLeds(resultado);
  mostrarFlags();

  imprimirBinario(a, 4); Serial.print(' '); Serial.print(nomeOp(op)); Serial.print(' ');
  imprimirBinario(b, 4); Serial.print(F(" = ")); imprimirBinario(resultado, 4);
  Serial.print(F("  (HEX ")); Serial.print(resultado, HEX); Serial.println(')');
  Serial.print(F("flags: C=")); Serial.print(flagC);
  Serial.print(F(" Z="));       Serial.print(flagZ);
  Serial.print(F(" N="));       Serial.print(flagN);
  Serial.print(F(" V="));       Serial.println(flagV);
}
