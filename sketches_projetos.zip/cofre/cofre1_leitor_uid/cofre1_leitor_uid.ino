/*
  COFRE RFID - FASE 1: barramento SPI, niveis logicos 5 V x 3,3 V e o UID do cartao

  O leitor RFID MFRC522 conversa com o Arduino pelo barramento SPI (4 fios + reset).
  ATENCAO: o MFRC522 funciona com 3,3 V. O Uno trabalha com 5 V.
    - Alimente o modulo com o pino 3.3V do Uno (NUNCA com 5V).
    - Use o CONVERSOR DE NIVEL LOGICO (lado HV = 5 V, lado LV = 3,3 V) nos sinais
      que saem do Arduino: SCK, MOSI, SDA(SS) e RST.
    - MISO (saida do modulo, 3,3 V) pode ir direto ao Arduino: 3,3 V ja e lido como ALTO.

  Ligacoes (Uno -> conversor -> MFRC522):
    13 (SCK)  -> HV1 / LV1 -> SCK       11 (MOSI) -> HV2 / LV2 -> MOSI
    10 (SS)   -> HV3 / LV3 -> SDA       9  (RST)  -> HV4 / LV4 -> RST
    12 (MISO) <- MISO (direto)          3.3V -> 3.3V do modulo e do lado LV
    5V -> lado HV do conversor          GND -> GND de tudo
    LED verde (300 ohms) no pino 7 | LED vermelho (300 ohms) no pino 6 | buzzer passivo no pino 5
  Biblioteca: MFRC522 (de Miguel Balboa). Instale pelo Gerenciador de Bibliotecas da IDE.

  O que o programa faz: ao aproximar um cartao ou chaveiro, mostra o UID
  (identificador unico, 4 bytes) em hexadecimal e binario, mais o tipo do cartao.
*/
#include <SPI.h>
#include <MFRC522.h>

const uint8_t PIN_SS = 10, PIN_RST = 9;
const uint8_t PIN_VERDE = 7, PIN_VERMELHO = 6, PIN_BUZZER = 5;
MFRC522 leitor(PIN_SS, PIN_RST);

void imprimirBinario(uint8_t v) {
  for (int8_t i = 7; i >= 0; i--) Serial.print((v >> i) & 1);
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_VERDE, OUTPUT); pinMode(PIN_VERMELHO, OUTPUT); pinMode(PIN_BUZZER, OUTPUT);
  SPI.begin();
  leitor.PCD_Init();
  Serial.println(F("=== COFRE RFID - Fase 1: leitor de UID ==="));
  Serial.print(F("Versao do chip MFRC522 (0x92 = v2.0, 0x91 = v1.0): 0x"));
  Serial.println(leitor.PCD_ReadRegister(MFRC522::VersionReg), HEX);
  Serial.println(F("Aproxime um cartao..."));
}

void loop() {
  if (!leitor.PICC_IsNewCardPresent() || !leitor.PICC_ReadCardSerial()) return;

  Serial.print(F("Tipo: ")); Serial.println(leitor.PICC_GetTypeName(leitor.PICC_GetType(leitor.uid.sak)));
  Serial.print(F("UID (")); Serial.print(leitor.uid.size); Serial.println(F(" bytes):"));
  uint8_t xorTotal = 0;
  for (uint8_t i = 0; i < leitor.uid.size; i++) {
    Serial.print(F("  byte ")); Serial.print(i);
    Serial.print(F(": HEX 0x")); if (leitor.uid.uidByte[i] < 16) Serial.print('0');
    Serial.print(leitor.uid.uidByte[i], HEX);
    Serial.print(F(" | BIN ")); imprimirBinario(leitor.uid.uidByte[i]);
    Serial.print(F(" | DEC ")); Serial.println(leitor.uid.uidByte[i]);
    xorTotal ^= leitor.uid.uidByte[i];
  }
  Serial.print(F("XOR dos bytes (checksum simples): 0x")); Serial.println(xorTotal, HEX);

  digitalWrite(PIN_VERDE, HIGH);
  tone(PIN_BUZZER, 1500, 120);
  delay(400);
  digitalWrite(PIN_VERDE, LOW);
  leitor.PICC_HaltA();
}
