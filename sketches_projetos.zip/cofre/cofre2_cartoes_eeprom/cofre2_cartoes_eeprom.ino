/*
  COFRE RFID - FASE 2: um mini "sistema de arquivos" na EEPROM

  Os cartoes autorizados ficam guardados na EEPROM (memoria que nao se apaga).
  Organizacao (como um disco minusculo):
      endereco 0..3  : CABECALHO  = numero magico 0xC0, versao, quantidade, reservado
      endereco 4...  : TABELA de ate 16 REGISTROS de 8 bytes cada:
           uid[4] | permissoes (1 byte) | acessos (2 bytes) | checksum (1 byte)
  O checksum (XOR dos 7 primeiros bytes) detecta registro corrompido.
  Permissoes: bit 0 = pode abrir | bit 1 = administrador

  Comandos no Monitor Serial:
     l = listar cartoes | a = cadastrar (o proximo cartao lido) | r = remover (o proximo cartao)
     f = formatar a tabela (apaga tudo)

  Ligacoes: as mesmas da Fase 1.
*/
#include <SPI.h>
#include <MFRC522.h>
#include <EEPROM.h>

const uint8_t PIN_SS = 10, PIN_RST = 9;
const uint8_t PIN_VERDE = 7, PIN_VERMELHO = 6, PIN_BUZZER = 5;
MFRC522 leitor(PIN_SS, PIN_RST);

const uint8_t MAGICO = 0xC0;
const uint8_t MAX_CARTOES = 16;
const uint8_t TAM_REG = 8;
const int INICIO_TABELA = 4;

struct Cartao {
  uint8_t  uid[4];
  uint8_t  perm;
  uint16_t acessos;
  uint8_t  soma;
};

char modo = 'u';          // u = uso normal | a = cadastrar | r = remover

uint8_t calcularSoma(const Cartao &c) {
  const uint8_t *p = (const uint8_t *)&c;
  uint8_t x = 0;
  for (uint8_t i = 0; i < TAM_REG - 1; i++) x ^= p[i];
  return x;
}

int enderecoDe(uint8_t i) { return INICIO_TABELA + i * TAM_REG; }

void lerRegistro(uint8_t i, Cartao &c) { EEPROM.get(enderecoDe(i), c); }
void gravarRegistro(uint8_t i, Cartao &c) { c.soma = calcularSoma(c); EEPROM.put(enderecoDe(i), c); }

void formatar() {
  EEPROM.update(0, MAGICO); EEPROM.update(1, 1); EEPROM.update(2, 0); EEPROM.update(3, 0);
  Cartao vazio;
  memset(&vazio, 0xFF, sizeof(vazio));
  for (uint8_t i = 0; i < MAX_CARTOES; i++) EEPROM.put(enderecoDe(i), vazio);
  Serial.println(F(">> tabela formatada"));
}

bool registroLivre(const Cartao &c) { return c.uid[0] == 0xFF && c.uid[1] == 0xFF && c.uid[2] == 0xFF && c.uid[3] == 0xFF; }

// Busca linear: devolve o indice do cartao ou -1
int buscar(const uint8_t *uid) {
  Cartao c;
  for (uint8_t i = 0; i < MAX_CARTOES; i++) {
    lerRegistro(i, c);
    if (!registroLivre(c) && memcmp(c.uid, uid, 4) == 0) return i;
  }
  return -1;
}

void listar() {
  Serial.println(F("--- tabela de cartoes (EEPROM) ---"));
  Cartao c;
  uint8_t n = 0;
  for (uint8_t i = 0; i < MAX_CARTOES; i++) {
    lerRegistro(i, c);
    if (registroLivre(c)) continue;
    n++;
    Serial.print(i); Serial.print(F(": UID "));
    for (uint8_t k = 0; k < 4; k++) { if (c.uid[k] < 16) Serial.print('0'); Serial.print(c.uid[k], HEX); Serial.print(' '); }
    Serial.print(F("| perm=")); Serial.print(c.perm, BIN);
    Serial.print(F(" | acessos=")); Serial.print(c.acessos);
    Serial.print(F(" | checksum ")); Serial.println(c.soma == calcularSoma(c) ? F("ok") : F("CORROMPIDO"));
  }
  Serial.print(F("Total: ")); Serial.print(n); Serial.print(F(" de ")); Serial.println(MAX_CARTOES);
}

void sinal(bool bom) {
  digitalWrite(bom ? PIN_VERDE : PIN_VERMELHO, HIGH);
  tone(PIN_BUZZER, bom ? 1500 : 300, bom ? 120 : 400);
  delay(500);
  digitalWrite(PIN_VERDE, LOW); digitalWrite(PIN_VERMELHO, LOW);
}

void tratarCartao(const uint8_t *uid) {
  int idx = buscar(uid);
  Cartao c;
  if (modo == 'a') {
    if (idx >= 0) { Serial.println(F("Cartao ja cadastrado.")); sinal(false); }
    else {
      for (uint8_t i = 0; i < MAX_CARTOES; i++) {
        lerRegistro(i, c);
        if (registroLivre(c)) {
          memcpy(c.uid, uid, 4); c.perm = 0b01; c.acessos = 0;
          gravarRegistro(i, c);
          Serial.print(F("Cadastrado na posicao ")); Serial.println(i);
          sinal(true);
          modo = 'u';
          return;
        }
      }
      Serial.println(F("Tabela cheia!")); sinal(false);
    }
    modo = 'u';
  } else if (modo == 'r') {
    if (idx < 0) { Serial.println(F("Cartao nao encontrado.")); sinal(false); }
    else {
      memset(&c, 0xFF, sizeof(c));
      EEPROM.put(enderecoDe(idx), c);
      Serial.println(F("Cartao removido.")); sinal(true);
    }
    modo = 'u';
  } else {
    if (idx >= 0) {
      lerRegistro(idx, c);
      c.acessos++;
      gravarRegistro(idx, c);             // so grava quando o contador muda
      Serial.print(F("ACESSO PERMITIDO | acessos deste cartao: ")); Serial.println(c.acessos);
      sinal(true);
    } else {
      Serial.println(F("ACESSO NEGADO"));
      sinal(false);
    }
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_VERDE, OUTPUT); pinMode(PIN_VERMELHO, OUTPUT); pinMode(PIN_BUZZER, OUTPUT);
  SPI.begin();
  leitor.PCD_Init();
  if (EEPROM.read(0) != MAGICO) { Serial.println(F("EEPROM sem formato: formatando...")); formatar(); }
  Serial.println(F("=== COFRE RFID - Fase 2 ==="));
  Serial.println(F("Comandos: l listar | a cadastrar | r remover | f formatar"));
  Serial.print(F("sizeof(Cartao) = ")); Serial.print(sizeof(Cartao)); Serial.println(F(" bytes"));
  listar();
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'l') listar();
    if (c == 'a') { modo = 'a'; Serial.println(F(">> aproxime o cartao a CADASTRAR")); }
    if (c == 'r') { modo = 'r'; Serial.println(F(">> aproxime o cartao a REMOVER")); }
    if (c == 'f') formatar();
  }
  if (!leitor.PICC_IsNewCardPresent() || !leitor.PICC_ReadCardSerial()) return;
  tratarCartao(leitor.uid.uidByte);
  leitor.PICC_HaltA();
}
