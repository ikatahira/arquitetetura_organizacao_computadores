/*
  COFRE RFID - FASE 3: trava com servo, permissoes (administrador) e registro de acessos

  Novidades:
    - Um micro servo SG90 faz de TRAVA: 0 graus = trancado, 90 graus = aberto (3 s).
    - Cadastro SEM computador: passe o cartao ADMINISTRADOR e, em ate 5 segundos,
      passe o cartao NOVO. Ele entra na tabela com permissao de abrir.
    - Um LOG circular de 16 eventos na EEPROM (a partir do endereco 160):
        evento = [indice do cartao | tipo | segundos desde o boot, 2 bytes]
      Quando enche, o evento novo sobrescreve o mais antigo.
    - Comandos: l listar cartoes | g mostrar o log | f formatar tudo | m promover o
      PRIMEIRO cartao cadastrado a administrador (use na primeira vez)
      e 'a' cadastra o proximo cartao lido (como na Fase 2)

  Ligacoes: as da Fase 1 e mais:  servo SG90: fio marrom GND, vermelho 5V, laranja pino 3
  (se o servo reiniciar a placa, alimente-o por uma fonte separada com GND comum).
*/
#include <SPI.h>
#include <MFRC522.h>
#include <EEPROM.h>
#include <Servo.h>

const uint8_t PIN_SS = 10, PIN_RST = 9;
const uint8_t PIN_VERDE = 7, PIN_VERMELHO = 6, PIN_BUZZER = 5, PIN_SERVO = 3;
MFRC522 leitor(PIN_SS, PIN_RST);
Servo trava;

const uint8_t MAGICO = 0xC0;
const uint8_t MAX_CARTOES = 16;
const uint8_t TAM_REG = 8;
const int INICIO_TABELA = 4;
const int INICIO_LOG = 160;
const uint8_t MAX_LOG = 16;
const uint8_t PERM_ABRIR = 0b01, PERM_ADMIN = 0b10;
const unsigned long JANELA_ADMIN_MS = 5000;

struct Cartao { uint8_t uid[4]; uint8_t perm; uint16_t acessos; uint8_t soma; };
struct Evento { uint8_t cartao; uint8_t tipo; uint16_t segundos; };

enum { EV_ABRIU = 1, EV_NEGADO = 2, EV_CADASTRO = 3 };
char modo = 'u';
unsigned long ate = 0;             // quando termina a janela do administrador
uint8_t ponteiroLog = 0;

uint8_t calcularSoma(const Cartao &c) {
  const uint8_t *p = (const uint8_t *)&c;
  uint8_t x = 0;
  for (uint8_t i = 0; i < TAM_REG - 1; i++) x ^= p[i];
  return x;
}
int enderecoDe(uint8_t i) { return INICIO_TABELA + i * TAM_REG; }
void lerRegistro(uint8_t i, Cartao &c) { EEPROM.get(enderecoDe(i), c); }
void gravarRegistro(uint8_t i, Cartao &c) { c.soma = calcularSoma(c); EEPROM.put(enderecoDe(i), c); }
bool registroLivre(const Cartao &c) { return c.uid[0] == 0xFF && c.uid[1] == 0xFF && c.uid[2] == 0xFF && c.uid[3] == 0xFF; }

void formatar() {
  EEPROM.update(0, MAGICO); EEPROM.update(1, 1); EEPROM.update(2, 0); EEPROM.update(3, 0);
  Cartao vazio; memset(&vazio, 0xFF, sizeof(vazio));
  for (uint8_t i = 0; i < MAX_CARTOES; i++) EEPROM.put(enderecoDe(i), vazio);
  Evento e; memset(&e, 0xFF, sizeof(e));
  for (uint8_t i = 0; i < MAX_LOG; i++) EEPROM.put(INICIO_LOG + i * sizeof(Evento), e);
  Serial.println(F(">> tudo formatado"));
}

int buscar(const uint8_t *uid) {
  Cartao c;
  for (uint8_t i = 0; i < MAX_CARTOES; i++) {
    lerRegistro(i, c);
    if (!registroLivre(c) && memcmp(c.uid, uid, 4) == 0) return i;
  }
  return -1;
}

void registrarEvento(uint8_t cartao, uint8_t tipo) {
  Evento e = { cartao, tipo, (uint16_t)(millis() / 1000) };
  EEPROM.put(INICIO_LOG + ponteiroLog * sizeof(Evento), e);
  ponteiroLog = (ponteiroLog + 1) % MAX_LOG;     // buffer circular
}

void descobrirPonteiroLog() {                    // acha a proxima posicao livre (0xFF) do log
  Evento e;
  ponteiroLog = 0;
  for (uint8_t i = 0; i < MAX_LOG; i++) {
    EEPROM.get(INICIO_LOG + i * sizeof(Evento), e);
    if (e.tipo == 0xFF) { ponteiroLog = i; return; }
  }
}

void mostrarLog() {
  Serial.println(F("--- log de acessos (posicao | cartao | evento | segundos desde o boot) ---"));
  Evento e;
  for (uint8_t i = 0; i < MAX_LOG; i++) {
    EEPROM.get(INICIO_LOG + i * sizeof(Evento), e);
    if (e.tipo == 0xFF) continue;
    Serial.print(i); Serial.print(F(" | ")); Serial.print(e.cartao); Serial.print(F(" | "));
    Serial.print(e.tipo == EV_ABRIU ? F("abriu") : e.tipo == EV_NEGADO ? F("negado") : F("cadastro"));
    Serial.print(F(" | ")); Serial.println(e.segundos);
  }
}

void listar() {
  Serial.println(F("--- cartoes ---"));
  Cartao c;
  for (uint8_t i = 0; i < MAX_CARTOES; i++) {
    lerRegistro(i, c);
    if (registroLivre(c)) continue;
    Serial.print(i); Serial.print(F(": "));
    for (uint8_t k = 0; k < 4; k++) { if (c.uid[k] < 16) Serial.print('0'); Serial.print(c.uid[k], HEX); }
    Serial.print(F(" perm=")); Serial.print(c.perm, BIN);
    Serial.print(F(" acessos=")); Serial.print(c.acessos);
    Serial.println(c.soma == calcularSoma(c) ? F(" ok") : F(" CORROMPIDO"));
  }
}

void sinal(bool bom) {
  digitalWrite(bom ? PIN_VERDE : PIN_VERMELHO, HIGH);
  tone(PIN_BUZZER, bom ? 1500 : 300, bom ? 120 : 400);
  delay(300);
  digitalWrite(PIN_VERDE, LOW); digitalWrite(PIN_VERMELHO, LOW);
}

void abrirTrava() {
  trava.attach(PIN_SERVO);
  trava.write(90);
  digitalWrite(PIN_VERDE, HIGH);
  delay(3000);
  trava.write(0);
  delay(400);
  trava.detach();
  digitalWrite(PIN_VERDE, LOW);
}

bool cadastrarNovo(const uint8_t *uid) {
  Cartao c;
  for (uint8_t i = 0; i < MAX_CARTOES; i++) {
    lerRegistro(i, c);
    if (registroLivre(c)) {
      memcpy(c.uid, uid, 4); c.perm = PERM_ABRIR; c.acessos = 0;
      gravarRegistro(i, c);
      registrarEvento(i, EV_CADASTRO);
      Serial.print(F("Cartao cadastrado na posicao ")); Serial.println(i);
      return true;
    }
  }
  return false;
}

void tratarCartao(const uint8_t *uid) {
  int idx = buscar(uid);
  Cartao c;

  if (modo == 'a') {                                  // cadastro pelo Serial
    modo = 'u';
    if (idx >= 0) { Serial.println(F("Ja cadastrado.")); sinal(false); }
    else if (cadastrarNovo(uid)) sinal(true); else { Serial.println(F("Tabela cheia")); sinal(false); }
    return;
  }

  if (modo == 'j' && millis() < ate) {                // janela aberta pelo administrador
    modo = 'u';
    if (idx >= 0) { Serial.println(F("Ja cadastrado.")); sinal(false); }
    else if (cadastrarNovo(uid)) sinal(true); else { Serial.println(F("Tabela cheia")); sinal(false); }
    return;
  }
  modo = 'u';

  if (idx < 0) { Serial.println(F("ACESSO NEGADO (cartao desconhecido)")); registrarEvento(255, EV_NEGADO); sinal(false); return; }

  lerRegistro(idx, c);
  if (c.perm & PERM_ADMIN) {                          // administrador: abre a janela de cadastro
    modo = 'j'; ate = millis() + JANELA_ADMIN_MS;
    Serial.println(F("ADMIN reconhecido: passe o cartao NOVO em ate 5 s"));
    tone(PIN_BUZZER, 2000, 80); delay(150); tone(PIN_BUZZER, 2000, 80);
    return;
  }
  if (c.perm & PERM_ABRIR) {
    c.acessos++;
    gravarRegistro(idx, c);
    registrarEvento(idx, EV_ABRIU);
    Serial.print(F("ACESSO PERMITIDO | acessos: ")); Serial.println(c.acessos);
    abrirTrava();
  } else {
    Serial.println(F("ACESSO NEGADO (sem permissao)"));
    registrarEvento(idx, EV_NEGADO);
    sinal(false);
  }
}

void setup() {
  Serial.begin(9600);
  pinMode(PIN_VERDE, OUTPUT); pinMode(PIN_VERMELHO, OUTPUT); pinMode(PIN_BUZZER, OUTPUT);
  trava.attach(PIN_SERVO); trava.write(0); delay(400); trava.detach();
  SPI.begin();
  leitor.PCD_Init();
  if (EEPROM.read(0) != MAGICO) { Serial.println(F("EEPROM sem formato: formatando...")); formatar(); }
  descobrirPonteiroLog();
  Serial.println(F("=== COFRE RFID - Fase 3 ==="));
  Serial.println(F("Comandos: l cartoes | g log | a cadastrar | m 1o cartao vira admin | f formatar"));
  Serial.print(F("sizeof(Evento) = ")); Serial.print(sizeof(Evento)); Serial.println(F(" bytes"));
  listar();
}

void loop() {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == 'l') listar();
    if (ch == 'g') mostrarLog();
    if (ch == 'a') { modo = 'a'; Serial.println(F(">> aproxime o cartao a CADASTRAR")); }
    if (ch == 'f') formatar();
    if (ch == 'm') {
      Cartao c; lerRegistro(0, c);
      if (!registroLivre(c)) { c.perm = PERM_ABRIR | PERM_ADMIN; gravarRegistro(0, c); Serial.println(F(">> cartao 0 agora e administrador")); }
    }
  }
  if (!leitor.PICC_IsNewCardPresent() || !leitor.PICC_ReadCardSerial()) return;
  tratarCartao(leitor.uid.uidByte);
  leitor.PICC_HaltA();
}
